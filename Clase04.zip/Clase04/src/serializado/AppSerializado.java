package serializado;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class AppSerializado {
    public static void main(String[] args) {
        File file=new File("personas.dat");
        
        //Serializado
        try (ObjectOutputStream out=new ObjectOutputStream(
                new FileOutputStream(file))){
            out.writeObject(new Persona("Carlos","Ríos",47));
            out.writeObject(new Persona("Laura","Casas",43));
            out.writeObject(new Persona("Nicolas","Leon",23));
            out.writeObject(new Persona("Dario","Riera",48));
            out.writeObject(new Persona("Carlos","Beltran",48));
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        //Deserializado
        List<Persona>list=new ArrayList();
        try (ObjectInputStream in=new ObjectInputStream(
                new FileInputStream(file))){
            while(true){
                Persona p=(Persona)in.readObject();
                //System.out.println(p);
                list.add(p);
            }
        } catch (EOFException e){ System.out.println("-- Fin de Archivo ---");
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        //list.forEach(System.out::println);
        
        list
                .stream()
                .filter(p->p.getNombre().equalsIgnoreCase("carlos"))
                .forEach(System.out::println);
        
    }
 
}
