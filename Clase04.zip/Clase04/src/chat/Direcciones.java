package chat;

import java.util.LinkedHashMap;
import java.util.Map;

public class Direcciones {
    public static Map<String,String>getMapa(){
        Map<String,String>map=new LinkedHashMap();
        map.put("Carlos", "192.168.0.3");
        map.put("Cristian", "192.168.0.6");
        return map;
    }
}
