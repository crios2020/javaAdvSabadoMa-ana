package ejercicio;

import java.util.ArrayList;
import java.util.List;

public class VehiculoRepository implements I_VehiculoRepository{

    List<Vehiculo>list;

    public VehiculoRepository() {
        list=new ArrayList();
        list.add(new Auto("Peugeot","206",200000,4));
        list.add(new Moto("Honda","Titan",60000,125));
        list.add(new Auto("Peugeot","208",250000,6));
        list.add(new Moto("Yamaha","YBR ",80500.5,160));
    }
    
    @Override
    public void save(Vehiculo vehiculo) {
        list.add(vehiculo);
    }

    @Override
    public void remove(Vehiculo vehiculo) {
        list.remove(vehiculo);
    }

    @Override
    public List<Vehiculo> getAll() {
        return list;
    }
    
}
