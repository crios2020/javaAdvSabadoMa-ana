package ejercicio;

import java.util.ArrayList;
import java.util.List;

public class App {
    private static List<Vehiculo>list=new ArrayList();
    public static void main(String[] args) {
        cargar();
        list.forEach(System.out::println);

        //usando un repositorio
        //I_VehiculoRepository vr=new VehiculoRepository();
        //vr.getAll().forEach(System.out::println);
        
        list.stream();
        list.stream();
        list.stream();
        list.stream();

        
    }
    
    private static void cargar(){
        //list.add(new Auto("Peugeot","206",200000,4));
        //list.add(new Moto("Honda","Titan",60000,125));
        //list.add(new Auto("Peugeot","208",250000,6));
        //list.add(new Moto("Yamaha","YBR ",80500.5,160));
        I_VehiculoRepository vr=new VehiculoRepository();
        list=vr.getAll();
    }
}
