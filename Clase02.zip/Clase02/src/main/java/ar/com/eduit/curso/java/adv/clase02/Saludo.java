package ar.com.eduit.curso.java.adv.clase02;
public class Saludo {
    public synchronized void saludo(String nombre,boolean esJefe){
        try {
            if(esJefe){
                System.out.println("Jefe: Hola Llegue!!!");
                
                notify();
                Thread.sleep(10);
                
                notify();
                Thread.sleep(10);
                
                notify();
                Thread.sleep(10);
                
                notify();
                Thread.sleep(10);
                
                notifyAll();
            }else{
                System.out.println("Llego "+nombre);
                wait();
                System.out.println(nombre+": Hola Jefe!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
