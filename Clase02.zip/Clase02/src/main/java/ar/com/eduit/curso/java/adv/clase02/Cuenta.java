package ar.com.eduit.curso.java.adv.clase02;
public class Cuenta {
    private float saldo=2000;
    public synchronized void depositar(float monto){
        System.out.println("-- Iniciando deposito! --");
        try { Thread.sleep(2000); } catch(Exception e){}
        saldo+=monto;
        System.out.println("-- Deposito terminado! --");
    }
    public void debitar(float monto){
        System.out.println("-- Iniciando debito! --");
        synchronized(this){             //JDK 7 o sup
            if(saldo>=monto){
               try { Thread.sleep(2000); } catch(Exception e){}
               saldo-=monto;
            }else{
                System.out.println("Fondos Insuficientes!!!!");
            }
        }
        System.out.println("-- Debito terminado! --");
    }
    public synchronized float getSaldo(){
        return saldo;
    }
}
