package ar.com.eduit.curso.java.adv.clase02;
public class Clase02 {
    public static void main(String[] args) {
        //Clase 02
        
        /*
            Ciclo de vida de un thread
        
        NEW             RUNNABLE        TIMEWAITING             BLOCKED     TERMINATED
        
        new Thread()    .start()        .wait() .sleep()        IO          .close()
        
        */
        
        HiloT hiloT1=new HiloT("hiloT1",120);
        HiloT hiloT2=new HiloT("hiloT2",800);
        HiloT hiloT3=new HiloT("hiloT3",600);
        HiloT hiloT4=new HiloT("hiloT4",400);
        
        hiloT4.setPriority(Thread.MAX_PRIORITY);
        hiloT3.setPriority(Thread.NORM_PRIORITY);
        hiloT2.setPriority(Thread.NORM_PRIORITY);
        hiloT1.setPriority(Thread.MIN_PRIORITY);
        
        System.out.println(hiloT1.getState());
        
        
        
        hiloT1.start();
        hiloT2.start();
        hiloT3.start();
        hiloT4.start();
        
        System.out.println(hiloT1.getState());
        
        //método join
        try {
            hiloT1.join();
            hiloT2.join();
            hiloT3.join();
            hiloT4.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        //try { Thread.sleep(11000); } catch(Exception e) {}
        
        System.out.println("-- Fin del programa --");
        System.out.println(hiloT1.getState());
    }
}
