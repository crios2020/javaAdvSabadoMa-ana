package ar.com.eduit.curso.java.adv.clase02;

public class AppOficina {
    public static void main(String[] args) {
        
        Saludo saludo=new Saludo();
        
        Empleado e1=new Empleado("Ana",false,saludo);
        Empleado e2=new Empleado("Raul",false,saludo);
        Empleado e3=new Empleado("Luis",false,saludo);
        Empleado e4=new Empleado("Marina",false,saludo);
        Empleado e5=new Empleado("Jeje",true,saludo);
        
        e1.start();
        e2.start();
        e3.start();
        e4.start();
        try { Thread.sleep(2000); } catch(Exception e){}
        e5.start();
    }
}
