package ar.com.eduit.curso.java.adv.clase02;

import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class appCuentas {
    public static void main(String[] args) throws Exception {
        Cuenta cuenta=new Cuenta();
        
        Cliente cliente1=new Cliente(cuenta);
        Cliente cliente2=new Cliente(cuenta);
        
        cliente1.start();
        cliente2.start();
        
        cliente1.join();
        cliente2.join();
        System.out.println(cuenta.getSaldo());
        
        /*
            Que diferencia hay entre HashMap y Hashtable?
        
        Hashtable:
            - Soporta MultiThread.
            - Los métodos son totalmente sincronizados.
            - Es lento.
            - Es una clase Legacy.
        
        HashMap:
            - No soporta MultiThread.
            - Los método no son sincronizados.
            - Es más veloz
        
        Collections: Es una clase que brinda utilidades estaticas, y puede factorizar
                        mapas o cualquier coleccion parcialmente sincronizadas. JDK 7 o sup.
        
        */
        
        //Hashtable<String,String>map=new Hashtable();
        //HashMap<String,String>map=new HashMap();
        Map<String,String>map=Collections.synchronizedMap(new HashMap<String,String>());
        
        map.put("lu","Lunes");
        map.put("ma","Martes");
        map.put("mi","Miércoles");
        map.put("ju","Jueves");
        map.put("vi","Viernes");
        System.out.println(map.get("ma"));
        
        StringBuffer sb=new StringBuffer();
        StringBuilder sb2=new StringBuilder();
        
        
        
    }
}
