package ar.com.eduit.curso.java.adv.clase01;
public class Clase01 {
    public static void main(String[] args) {
        /*
        Curso: Java Advanced 15 horas
        Días: Sábado 10:00 a 13:00 hs
        Profe: Carlos Ríos  carlos.rios@educacionit.com
        
        Materiales: alumni.educacionit.com
        github: https://github.com/crios2020/javaAdvSabadoMa-ana
        
        JDK: Versiones LTS Long Term Support        (8 años)
        
        Versión             Liberado                Vence 
        JDK 8.X LTS         Marzo 2014              Marzo 2022            
        JDK 9               Octubre 2017            Marzo 2018
        JDK 10              Marzo 2018              Octubre 2018
        JDK 11 LTS          Octubre 2018            Octubre 2026
        JDK 12              Marzo 2019              Octubre 2019
        JDK 13              Octubre 2019            Marzo 2020
        JDK 14              Marzo 2020              Octubre 2020
        JDK 15              Octubre 2020            Marzo 2021
        JDK 16              Marzo 2021              Octubre 2021
        JDK 17 LTS          Octubre 2021            Octubre 2029
        
        */
        
        
        /*
            
        Tarea 1:    Leer file1 en medio1, tiempo 10 segundos.
        
        Tarea 2:    Leer file2 en medio2, tiempo 10 segundos.
        
        Tarea 3:    Abrir form, mostrar file1 y file2, tiempo 1 segundo.
        
           Tarea 1   Tarea 2   Tarea 3
        |----------|----------|-|
            10 s       10 s    1 s
        
        Total: 21 segundos
        
           Tarea 1 
        |----------|
            10 s
        
           Tarea 2 
        |----------|
            10 s
        
                    Tarea 3
                   |-|
                    1 s
        
        Total: 11 segundos
        
           Tarea 1 
        |----------|
            10 s
        
           Tarea 2 
        |----------|
            10 s
        
        Tarea 3
        |-|
         1 s
        
        Total: 10 segundos
        
        */
        
        HiloT hiloT1=new HiloT("hiloT1");
        HiloT hiloT2=new HiloT("hiloT2");
        HiloT hiloT3=new HiloT("hiloT3");
        HiloT hiloT4=new HiloT("hiloT4");
        
        
        // método .run()
        // invocar directamente el método .run() no abre un nuevo hilo de ejecución
        //hiloT1.run();
        //hiloT2.run();
        //hiloT3.run();
        //hiloT4.run();
        
        // método .start()
        // El método .start() ejecuta al método .run() en un nuevo hilo.
        //hiloT1.start();
        //hiloT2.start();
        //hiloT3.start();
        //hiloT4.start();
        //abrir un Thread anonimo
        //new HiloT("hiloT5").start();
        
        
        //Interface Runnable
       
        HiloR hiloR1=new HiloR("hiloR1");
        HiloR hiloR2=new HiloR("hiloR2");
        HiloR hiloR3=new HiloR("hiloR3");
        HiloR hiloR4=new HiloR("hiloR4");
        HiloR hiloR6=new HiloR("hiloR6");
        
        Thread t1=new Thread(hiloR1);
        Thread t2=new Thread(hiloR2);
        Thread t3=new Thread(hiloR3);
        Thread t4=new Thread(hiloR4);
        //Runnable anonimo
        Thread t5=new Thread(new HiloR("hiloR5"));
        
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
        //Thread anonimo
        new Thread(hiloR6).start();
        
        //Runnable anonimo, Thread anonimo
        new Thread(new HiloR("hiloR7")).start();
        
        
    }
}
