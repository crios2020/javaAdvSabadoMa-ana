package ar.com.eduit.curso.java.adv.clase01;

public class HiloT extends Thread{
    // Thread permite ejecutar un método en un nuevo hilo
    
    private String nombre;

    public HiloT(String nombre) {
        this.nombre = nombre;
    }
    
    @Override
    public void run(){
        //Este método puede ejecutar en un nuevo hilo
        
        for(int a=1; a <=10; a++){
            System.out.println(nombre+" "+a);
            try { Thread.sleep(1000); } catch(Exception e) {}
        }
    }
    
}
