package ejercicio;

import java.util.ArrayList;
import java.util.List;

public class VehiculoRepository implements I_VehiculoRepository{

    List<Vehiculo>list;

    public VehiculoRepository() {
        list=new ArrayList();
    }
    
    @Override
    public void save(Vehiculo vehiculo) {
        list.add(vehiculo);
    }

    @Override
    public void remove(Vehiculo vehiculo) {
        list.remove(vehiculo);
    }

    @Override
    public List<Vehiculo> getAll() {
        return list;
    }
    
}
