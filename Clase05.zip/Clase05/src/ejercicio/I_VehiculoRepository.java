package ejercicio;

import java.util.List;

public interface I_VehiculoRepository {
    void save(Vehiculo vehiculo);
    void remove(Vehiculo vehiculo);
    List<Vehiculo>getAll();
}
