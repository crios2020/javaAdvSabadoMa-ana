package ejercicio;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import certificacion.Examen;
//import certificacion.Examen2;

public class App {
    private static List<Vehiculo>list=new ArrayList();
    public static void main(String[] args) {
        cargar();
        list.forEach(System.out::println);

        System.out.println();
        System.out.println("=============================");
        System.out.println();
        
        //Esto funciona si existe un solo vehiculo con el precio más caro.
        // si existe otro vehiculo con 250000 $ de precio, no seria listado.
        /*
        Vehiculo vehiculoMasCaro= list
                .stream()
                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get();
        
        System.out.println("Vehículo más caro: "
                +vehiculoMasCaro.getMarca()+" "
                +vehiculoMasCaro.getModelo());
        */
        /*
        select max(precio) from vehiculos;              250000
        select * from vehiculos where precio=(select max(precio) from vehiculos);  
        */
        
        //Vehiculo Mas Caro
        double precioVehiculoMasCaro=list
                .stream()
                .max(Comparator.comparing(Vehiculo::getPrecio))
                .get()
                .getPrecio();
        
        list
                .stream()
                .filter(v->v.getPrecio()==precioVehiculoMasCaro)
                .forEach(v->System.out.println("Vehículo más caro: "+v.getMarca()+" "+v.getModelo()));
        
        
        //Vehiculo Más barato
        double precioVehiculoMasBarato=list
                .stream()
                .min(Comparator.comparing(Vehiculo::getPrecio))
                .get()
                .getPrecio();
        
        list
                .stream()
                .filter(v->v.getPrecio()==precioVehiculoMasBarato)
                .forEach(v->System.out.println("Vehículo más barato: "+v.getMarca()+" "+v.getModelo()));
        
        //Vehiculo Modelo contiene Y
        list
                .stream()
                .filter(v->v.getModelo().contains("Y"))
                .forEach(v->System.out.println(
                        "Vehículo que contiene en el modelo la letra ‘Y’: "
                        +v.getMarca()+" "+v.getMarca()+" $"+v.getPrecioFormat()));
        
        System.out.println();
        System.out.println("=============================");
        System.out.println();
        System.out.println("Vehículos ordenados por precio de mayor a menor:");
        list
                .stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                .forEach(v->System.out.println(v.getMarca()+" "+v.getModelo()));
        
        System.out.println();
        System.out.println("=============================");
        System.out.println();
        System.out.println("Vehículos ordenados por orden natural:");
        list
                .stream()
                .sorted()
                .forEach(System.out::println);
        
        
    }
    
    private static void cargar(){
        //sin repositorio.
        //list.add(new Auto("Peugeot","206",200000,4));
        //list.add(new Moto("Honda","Titan",60000,125));
        //list.add(new Auto("Peugeot","208",250000,6));
        //list.add(new Moto("Yamaha","YBR ",80500.5,160));
        
        
        // con repositorio
        I_VehiculoRepository vr=new VehiculoRepository();
        vr.save(new Auto("Peugeot","206",200000,4));
        vr.save(new Moto("Honda","Titan",60000,125));
        vr.save(new Auto("Peugeot","208",250000,6));
        vr.save(new Moto("Yamaha","YBR ",80500.5,160));
        vr.save(new Moto("Honda","PCR",250000,150));
        list=vr.getAll();
    }
}
