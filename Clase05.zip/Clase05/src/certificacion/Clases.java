package certificacion;


public class Clases {
    
    //Local Member Class
    public class ClaseInternaMiembro{
        // atributos
        
        // metodos
    }
    
    void metodo(){
        ClaseInternaMiembro cim=new ClaseInternaMiembro();
        
        //LocalNestedClass
        class LocalNestedClass{
            
        }
        
        LocalNestedClass lnc=new LocalNestedClass();
         
    }
    
    
}

//Clase de archivo compartido
class Clases2{}


interface I_CabezaMamifero{
    
}

//class CabezaHumano implements I_CabezaMamifero{
//    
//}

class Humano{
    private class CabezaHumano implements I_CabezaMamifero{
        
        
    }
    private CabezaHumano cabeza=new CabezaHumano();
    
    public void metodo(){
        
    }
}