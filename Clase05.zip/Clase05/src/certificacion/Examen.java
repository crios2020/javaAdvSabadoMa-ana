package certificacion;

public final class Examen {}
abstract class Examen2{}
class Examen3 extends Examen2{}

interface I_Archivo{}
interface I_Nube{}

enum Dia {LUNES, MARTES, MIERCOLES, JUEVES, VIERNES, SABADO, DOMINGO}
enum Estaciones {PRIMAVERA, VERANO, OTOÑO, INVIERNO} 

//identificadores
class _X{
    int _x;
}

class ${}

//class #x{}
//class ?X{}

class X1{}
//class 1X{}


