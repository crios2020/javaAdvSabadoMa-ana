package certificacion;

public class _C {
    private static int $;
    public static void main(String[] main) {
        String a_b;
        System.out.print($);
        //System.out.print(a_b);
        //Examen2 ex=new Examen2();
    }
}
