package clase04;

public class Hola{
	public static void main(String... args){ //varargs JDK 5 o superior
		System.out.println("Hola Mundo!");
		
		//System.out.println("Longitud del vector args: "+args.length);
		//for(int a=0;a<args.length;a++) System.out.println(args[a]);
		
		//String[] semana={"Lunes","Martes","Miércoles","Jueves","Viernes"};
		//metodo1(semana);
		//metodo2(semana);
		metodo2("Lunes","Martes","Miércoles","Jueves","Viernes");
		
	}
	
	public static void metodo1(String[] vector){
		for(int a=0;a<vector.length;a++) System.out.println(vector[a]);
	}
	
	public static void metodo2(String... args){
		for(int a=0;a<args.length;a++) System.out.println(args[a]);
	}
}
